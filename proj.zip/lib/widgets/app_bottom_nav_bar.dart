import 'package:flutter/material.dart';

/// A single destination in [AppBottomNavBar].
class AppNavItem {
  const AppNavItem({required this.icon, required this.activeIcon, required this.label});

  final IconData icon;
  final IconData activeIcon;
  final String label;
}

/// A floating, pill-style bottom navigation bar.
///
/// Replaces the stock [BottomNavigationBar] with a rounded, elevated
/// island that sits above the screen edge. The selected item grows into
/// a colored pill with its label revealed next to the icon; unselected
/// items stay as plain, muted icons. Switching tabs animates the pill
/// sliding/resizing rather than just swapping colors.
class AppBottomNavBar extends StatelessWidget {
  const AppBottomNavBar({
    super.key,
    required this.items,
    required this.currentIndex,
    required this.onTap,
  });

  final List<AppNavItem> items;
  final int currentIndex;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final navTheme = Theme.of(context).bottomNavigationBarTheme;
    final barColor = navTheme.backgroundColor ?? Theme.of(context).cardColor;
    final accent = scheme.secondary;
    final unselected = navTheme.unselectedItemColor ?? scheme.onSurface.withOpacity(0.4);

    return SafeArea(
      top: false,
      minimum: const EdgeInsets.fromLTRB(12, 0, 12, 8),
      child: Container(
        height: 64,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: barColor,
          borderRadius: BorderRadius.circular(28),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.16),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            for (var i = 0; i < items.length; i++)
              Expanded(
                child: _NavItemButton(
                  item: items[i],
                  selected: i == currentIndex,
                  accent: accent,
                  unselectedColor: unselected,
                  onTap: () => onTap(i),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _NavItemButton extends StatelessWidget {
  const _NavItemButton({
    required this.item,
    required this.selected,
    required this.accent,
    required this.unselectedColor,
    required this.onTap,
  });

  final AppNavItem item;
  final bool selected;
  final Color accent;
  final Color unselectedColor;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: LayoutBuilder(
        builder: (context, constraints) {
          return Center(
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 260),
              curve: Curves.easeOutCubic,
              padding: EdgeInsets.symmetric(horizontal: selected ? 14 : 10, vertical: 8),
              constraints: BoxConstraints(maxWidth: constraints.maxWidth),
              decoration: BoxDecoration(
                color: selected ? accent.withOpacity(0.16) : Colors.transparent,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    transitionBuilder: (child, animation) => ScaleTransition(scale: animation, child: child),
                    child: Icon(
                      selected ? item.activeIcon : item.icon,
                      key: ValueKey(selected),
                      size: 24,
                      color: selected ? accent : unselectedColor,
                    ),
                  ),
                  Flexible(
                    child: AnimatedSize(
                      duration: const Duration(milliseconds: 260),
                      curve: Curves.easeOutCubic,
                      alignment: Alignment.centerLeft,
                      child: selected
                          ? Padding(
                              padding: const EdgeInsets.only(left: 6),
                              child: Text(
                                item.label,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                softWrap: false,
                                style: TextStyle(
                                  color: accent,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            )
                          : const SizedBox(width: 0, height: 0),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
