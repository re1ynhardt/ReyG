import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../l10n/app_strings.dart';
import '../../models/user.dart';
import '../../providers/app_state.dart';
import '../../providers/auth_provider.dart';
import '../../theme/app_theme.dart';
import 'featured_tags_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  static const _maxAvatarBytes = 5 * 1024 * 1024;

  bool _uploadingAvatar = false;
  bool _updatingPrivacy = false;
  bool _updatingPassword = false;

  Future<void> _changePassword() async {
    if (_updatingPassword) return;
    final formKey = GlobalKey<FormState>();
    final newController = TextEditingController();
    final confirmController = TextEditingController();

    final newPassword = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(dialogContext.tr('change_password')),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: newController,
                obscureText: true,
                autofocus: true,
                decoration: InputDecoration(labelText: dialogContext.tr('new_password')),
                validator: (v) => (v == null || v.isEmpty) ? dialogContext.tr('password_required') : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: confirmController,
                obscureText: true,
                decoration: InputDecoration(labelText: dialogContext.tr('confirm_password')),
                validator: (v) => v != newController.text ? dialogContext.tr('password_mismatch') : null,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: Text(dialogContext.tr('cancel')),
          ),
          TextButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                Navigator.of(dialogContext).pop(newController.text);
              }
            },
            child: Text(dialogContext.tr('save')),
          ),
        ],
      ),
    );

    if (newPassword == null || !mounted) return;

    setState(() => _updatingPassword = true);
    try {
      await context.read<AuthProvider>().setPassword(newPassword);
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(_trStatic(context, 'password_updated'))));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    } finally {
      if (mounted) setState(() => _updatingPassword = false);
    }
  }

  Future<void> _setLikesPrivacy(String privacy) async {
    if (_updatingPrivacy) return;
    setState(() => _updatingPrivacy = true);
    try {
      await context.read<AuthProvider>().setLikesPrivacy(privacy);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    } finally {
      if (mounted) setState(() => _updatingPrivacy = false);
    }
  }

  String _initial(String? name) {
    if (name == null || name.isEmpty) return '?';
    return name.substring(0, 1).toUpperCase();
  }

  /// Same lookup as `context.tr()`, but reads the locale without
  /// subscribing to changes — safe to call from inside async event
  /// handlers (after an `await`), where `context.tr()`'s `listen: true`
  /// would trip Provider's "used outside build" assertion.
  String _trStatic(BuildContext context, String key) {
    final locale = context.read<AppState>().locale;
    return AppStrings.t(locale, key);
  }

  Future<void> _pickAndUploadAvatar() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image);
    final picked = result?.files.single;
    if (picked?.path == null) return;

    if ((picked!.size) > _maxAvatarBytes) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(_trStatic(context, 'avatar_too_large'))));
      }
      return;
    }

    setState(() => _uploadingAvatar = true);
    try {
      await context.read<AuthProvider>().uploadAvatar(picked.path!);
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(_trStatic(context, 'avatar_updated'))));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    } finally {
      if (mounted) setState(() => _uploadingAvatar = false);
    }
  }

  Widget _buildAvatar(BuildContext context, String? avatarUrl, String? displayName) {
    final url = (avatarUrl != null && avatarUrl.isNotEmpty) ? avatarUrl : null;
    final ImageProvider? image =
        url == null ? null : (url.startsWith('http') ? CachedNetworkImageProvider(url) : FileImage(File(url)) as ImageProvider);
    return SizedBox(
      width: 48,
      height: 48,
      child: Stack(
        children: [
          CircleAvatar(
            radius: 24,
            backgroundImage: image,
            child: image == null ? Text(_initial(displayName)) : null,
          ),
          if (_uploadingAvatar)
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.45),
                  shape: BoxShape.circle,
                ),
                child: const Padding(
                  padding: EdgeInsets.all(12),
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                ),
              ),
            )
          else
            Positioned(
              right: -2,
              bottom: -2,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.secondary,
                  shape: BoxShape.circle,
                  border: Border.all(color: Theme.of(context).scaffoldBackgroundColor, width: 2),
                ),
                child: const Padding(
                  padding: EdgeInsets.all(3),
                  child: Icon(Icons.edit, size: 12, color: Colors.white),
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(context.tr('settings'))),
      body: ListView(
        children: [
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(context.tr('account'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          ),
          ListTile(
            leading: GestureDetector(
              onTap: _uploadingAvatar ? null : _pickAndUploadAvatar,
              child: _buildAvatar(context, auth.user?.avatarUrl, auth.user?.displayName),
            ),
            title: Text(auth.user?.displayName ?? ''),
            subtitle: Text(auth.user?.email ?? ''),
            trailing: auth.isDeveloper
                ? Chip(
                    label: Text(context.tr('developer_account'), style: const TextStyle(fontSize: 11)),
                    avatar: const Icon(Icons.verified, size: 16),
                  )
                : null,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
            child: Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: _uploadingAvatar ? null : _pickAndUploadAvatar,
                icon: const Icon(Icons.photo_camera_outlined, size: 18),
                label: Text(context.tr('change_avatar')),
                style: TextButton.styleFrom(padding: EdgeInsets.zero, alignment: Alignment.centerLeft),
              ),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.lock_outline),
            title: Text(context.tr('change_password')),
            onTap: _updatingPassword ? null : _changePassword,
            trailing: _updatingPassword
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.chevron_right),
          ),
          const Divider(height: 24),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(context.tr('privacy_section'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
            child: Text(
              context.tr('likes_privacy_subtitle'),
              style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor),
            ),
          ),
          RadioListTile<String>(
            title: Text(context.tr('privacy_everyone')),
            subtitle: Text(context.tr('privacy_everyone_desc')),
            value: LikesPrivacy.all,
            groupValue: auth.user?.likesPrivacy ?? LikesPrivacy.all,
            onChanged: _updatingPrivacy ? null : (v) => _setLikesPrivacy(v!),
          ),
          RadioListTile<String>(
            title: Text(context.tr('privacy_favorites_only')),
            subtitle: Text(context.tr('privacy_favorites_only_desc')),
            value: LikesPrivacy.favoritesOnly,
            groupValue: auth.user?.likesPrivacy ?? LikesPrivacy.all,
            onChanged: _updatingPrivacy ? null : (v) => _setLikesPrivacy(v!),
          ),
          RadioListTile<String>(
            title: Text(context.tr('privacy_nobody')),
            subtitle: Text(context.tr('privacy_nobody_desc')),
            value: LikesPrivacy.none,
            groupValue: auth.user?.likesPrivacy ?? LikesPrivacy.all,
            onChanged: _updatingPrivacy ? null : (v) => _setLikesPrivacy(v!),
          ),
          const Divider(height: 24),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(context.tr('language'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          ),
          RadioListTile<String>(
            title: const Text('English'),
            value: AppStrings.en,
            groupValue: appState.locale,
            onChanged: (v) => appState.setLocale(v!),
          ),
          RadioListTile<String>(
            title: const Text('Русский'),
            value: AppStrings.ru,
            groupValue: appState.locale,
            onChanged: (v) => appState.setLocale(v!),
          ),
          const Divider(height: 24),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(context.tr('theme'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          ),
          ...AppThemeOption.values.map(
            (option) => RadioListTile<AppThemeOption>(
              title: Text(context.tr(option.labelKey)),
              secondary: CircleAvatar(
                radius: 14,
                backgroundColor: option.swatch,
                child: Icon(option.icon, size: 14, color: option.isDark ? Colors.white : Colors.black87),
              ),
              value: option,
              groupValue: appState.themeOption,
              onChanged: (v) => appState.setTheme(v!),
            ),
          ),
          if (auth.isDeveloper) ...[
            const Divider(height: 24),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(context.tr('developer_account'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            ),
            ListTile(
              leading: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.secondary,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.tag, color: Colors.white),
              ),
              title: Text(context.tr('select_tags'), style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(context.tr('select_tags_subtitle'), style: const TextStyle(fontSize: 12)),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const FeaturedTagsScreen())),
            ),
          ],
          const Divider(height: 24),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: Text(context.tr('logout'), style: const TextStyle(color: Colors.red)),
            onTap: () => auth.logout(),
          ),
        ],
      ),
    );
  }
}
