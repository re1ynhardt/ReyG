import 'package:flutter/foundation.dart';
import '../models/playlist.dart';
import '../models/track.dart';
import '../models/user.dart';
import '../services/api_service.dart';

/// Backs the Community tab: the full list of registered users, plus a
/// simple client-side filter by display name for the search field at the
/// top of that screen.
class CommunityProvider extends ChangeNotifier {
  CommunityProvider(this._api);

  final ApiService _api;

  List<AppUser> _users = [];
  Set<String> _favoriteUserIds = {};
  bool _loading = false;
  String _query = '';

  bool get loading => _loading;
  String get query => _query;

  /// IDs of accounts the signed-in user has favorited, so screens can
  /// check `favoriteUserIds.contains(user.id)` to show the right icon
  /// state without re-fetching.
  Set<String> get favoriteUserIds => _favoriteUserIds;

  bool isFavoriteUser(String userId) => _favoriteUserIds.contains(userId);

  /// Looks up a cached user by id — e.g. to resolve a DM conversation's
  /// counterpart into a display name/avatar on the Messages tab. Returns
  /// null if the list hasn't been loaded yet or the id isn't found;
  /// callers should fall back to a generic placeholder in that case.
  AppUser? userById(String id) {
    for (final u in _users) {
      if (u.id == id) return u;
    }
    return null;
  }

  /// Users matching [_query] (case-insensitive, matched anywhere in the
  /// display name), with favorited accounts pinned first — each group
  /// keeps the alphabetical order the backend already returned.
  List<AppUser> get users {
    final term = _query.trim().toLowerCase();
    final filtered = term.isEmpty
        ? _users
        : _users.where((u) => u.displayName.toLowerCase().contains(term)).toList();
    final favorites = filtered.where((u) => _favoriteUserIds.contains(u.id)).toList();
    final rest = filtered.where((u) => !_favoriteUserIds.contains(u.id)).toList();
    return [...favorites, ...rest];
  }

  Future<void> loadUsers() async {
    _loading = true;
    notifyListeners();
    try {
      final results = await Future.wait([_api.fetchAllUsers(), _api.fetchFavoriteUserIds()]);
      _users = results[0] as List<AppUser>;
      _favoriteUserIds = (results[1] as List<String>).toSet();
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  void search(String query) {
    _query = query;
    notifyListeners();
  }

  /// Tracks [userId] has liked, for the Community profile screen. Not
  /// cached on the provider — each profile view fetches fresh.
  Future<List<Track>> fetchUserLikedTracks(String userId) => _api.fetchFavoriteTracksByUser(userId);

  /// Playlists owned by [userId], for the Community profile screen.
  Future<List<Playlist>> fetchUserPlaylists(String userId) => _api.fetchPlaylistsByUser(userId);

  /// Whether the signed-in user is allowed to see [userId]'s liked
  /// tracks and playlists, per that account's privacy setting. The
  /// Community profile screen checks this before showing (or hiding)
  /// the tracks/playlists cards.
  Future<bool> canViewUserLibrary(String userId) => _api.canViewUserLibrary(userId);

  /// Developer-only. Permanently deletes [userId]'s account, its
  /// playlists and its favorites, then drops it from the locally cached
  /// user list so the Community tab reflects the removal immediately.
  Future<void> deleteUserAccount(String userId) async {
    await _api.deleteUserAccount(userId);
    _users = _users.where((u) => u.id != userId).toList();
    _favoriteUserIds.remove(userId);
    notifyListeners();
  }

  /// Developer-only. Sets [userId]'s password without requiring their
  /// old one — used by the debug sheet on a user's Community profile.
  Future<void> setUserPassword({required String userId, required String newPassword}) {
    return _api.setUserPassword(userId: userId, newPassword: newPassword);
  }

  /// Developer-only (strictly — support accounts can't call this
  /// either). Re-syncs every account's role flags with the app's
  /// current developer/support/performer email lists, then reloads the
  /// locally cached user list so any changed badges show up right away.
  /// Returns the number of accounts whose role actually changed.
  Future<int> syncAccountRoles() async {
    final updated = await _api.syncAccountRoles();
    await loadUsers();
    return updated;
  }

  /// Developer/support-only. Straight passthrough to [ApiService.publishAppUpdate] —
  /// uploads the picked APK and rewrites `app/update.json` so every device's
  /// next "check for updates" (or silent startup check) picks it up.
  Future<void> publishAppUpdate({
    required String localApkPath,
    required String version,
    required int buildNumber,
    required String notes,
    required bool mandatory,
  }) {
    return _api.publishAppUpdate(
      localApkPath: localApkPath,
      version: version,
      buildNumber: buildNumber,
      notes: notes,
      mandatory: mandatory,
    );
  }

  /// Toggles whether [userId] is one of the signed-in user's favorite
  /// accounts. Updates optimistically (so the star/list reorders
  /// instantly) and rolls back if the backend call fails.
  Future<void> toggleFavoriteUser(String userId) async {
    final nowFavorite = !_favoriteUserIds.contains(userId);
    if (nowFavorite) {
      _favoriteUserIds.add(userId);
    } else {
      _favoriteUserIds.remove(userId);
    }
    notifyListeners();
    try {
      await _api.setFavoriteUser(userId: userId, favorite: nowFavorite);
    } catch (e) {
      if (nowFavorite) {
        _favoriteUserIds.remove(userId);
      } else {
        _favoriteUserIds.add(userId);
      }
      notifyListeners();
      rethrow;
    }
  }
}
